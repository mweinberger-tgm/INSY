DROP TABLE IF EXISTS Person, Segler, Trainer, Boot, Tourenboot, Sportboot, Mannschaft, Regatta, Wettfahrt CASCADE;
DROP TABLE IF EXISTS bildet, zugewiesen, nimmt_teil, erzielt;